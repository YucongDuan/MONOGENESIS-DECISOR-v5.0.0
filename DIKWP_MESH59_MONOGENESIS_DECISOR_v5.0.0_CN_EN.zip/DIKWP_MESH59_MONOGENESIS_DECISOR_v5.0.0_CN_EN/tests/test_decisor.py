from copy import deepcopy
from decisor59.polarity import compile_polarity_registry
from decisor59.millennium import registry
from decisor59.conformance import run_conformance
from decisor59.ledger import EvidenceLedger

def test_registry_total_and_bounded():
    r=compile_polarity_registry([])
    assert r['packet_count']==36 and r['true_count']==33 and r['false_count']==3 and r['no_unknown']
    assert all(p['verdict_label'] in {'TRUE','FALSE'} for p in r['packets'])
    assert all(p['decisive_lemma'] and p['kill_tests'] for p in r['packets'])

def test_millennium_and_boundaries():
    m=registry();assert m['count']==7
    assert next(x for x in m['packets'] if x['problem_id']=='p-vs-np')['candidate_verdict'].startswith('FALSE')
    assert next(x for x in m['packets'] if x['problem_id']=='poincare')['official_status']=='SOLVED'

def test_conformance_and_tamper():
    assert run_conformance()['all_passed']
    l=EvidenceLedger();l.append('x',{'a':1});assert l.verify()['valid']
    bad=deepcopy(l);object.__setattr__(bad.records[0],'payload',{'a':2});assert not bad.verify()['valid']
