from pathlib import Path
import json, math
from docx import Document
from docx.shared import Inches, Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE

ROOT=Path(__file__).resolve().parents[1]
RUN=json.load(open(ROOT/'outputs/reference/reference_run.json',encoding='utf-8'))
P=RUN['polarity']['packets']; BY={x['problem_id']:x for x in P}; M=RUN['millennium']['packets']; EXP=RUN['experiments']
OUT=ROOT/'reports/DIKWP_MESH59_MONOGENESIS_DECISOR_全命题极性与千禧年证明战役综合报告_CN_EN.docx'

def shade(cell,fill):
    tcPr=cell._tc.get_or_add_tcPr();shd=OxmlElement('w:shd');shd.set(qn('w:fill'),fill);tcPr.append(shd)
def margins(cell,top=80,start=90,bottom=80,end=90):
    tc=cell._tc;tcPr=tc.get_or_add_tcPr();tcMar=tcPr.first_child_found_in('w:tcMar')
    if tcMar is None:tcMar=OxmlElement('w:tcMar');tcPr.append(tcMar)
    for m,v in [('top',top),('start',start),('bottom',bottom),('end',end)]:
        e=tcMar.find(qn('w:'+m))
        if e is None:e=OxmlElement('w:'+m);tcMar.append(e)
        e.set(qn('w:w'),str(v));e.set(qn('w:type'),'dxa')
def set_repeat_table_header(row):
    trPr=row._tr.get_or_add_trPr();tblHeader=OxmlElement('w:tblHeader');tblHeader.set(qn('w:val'),'true');trPr.append(tblHeader)
def add_page_num(paragraph):
    paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER
    run=paragraph.add_run();fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');run._r.addnext(fld)
def set_run_font(run,size=None,bold=None,color=None,font='Noto Sans CJK SC'):
    run.font.name=font;run._element.rPr.rFonts.set(qn('w:eastAsia'),font)
    if size:run.font.size=Pt(size)
    if bold is not None:run.bold=bold
    if color:run.font.color.rgb=RGBColor(*color)
def set_cell_text(cell,text,size=8,bold=False,color=None):
    cell.text='';p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(0);r=p.add_run(str(text));set_run_font(r,size,bold,color);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER;margins(cell)

doc=Document();sec=doc.sections[0];sec.page_width=Cm(21);sec.page_height=Cm(29.7);sec.top_margin=Cm(2.0);sec.bottom_margin=Cm(1.8);sec.left_margin=Cm(2.1);sec.right_margin=Cm(2.1)
# Styles
styles=doc.styles
normal=styles['Normal'];normal.font.name='Noto Sans CJK SC';normal._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');normal.font.size=Pt(10.5);normal.paragraph_format.line_spacing=1.25;normal.paragraph_format.space_after=Pt(6)
for name,size,color in [('Title',27,(12,44,76)),('Subtitle',15,(45,101,135)),('Heading 1',18,(12,65,98)),('Heading 2',14,(24,88,120)),('Heading 3',11.5,(45,101,135))]:
    s=styles[name];s.font.name='Noto Sans CJK SC';s._element.rPr.rFonts.set(qn('w:eastAsia'),'Noto Sans CJK SC');s.font.size=Pt(size);s.font.color.rgb=RGBColor(*color);s.font.bold=True
# custom code style
if 'CodeBlock' not in styles:
    cs=styles.add_style('CodeBlock',WD_STYLE_TYPE.PARAGRAPH);cs.font.name='DejaVu Sans Mono';cs.font.size=Pt(8.5);cs.paragraph_format.left_indent=Cm(.5);cs.paragraph_format.right_indent=Cm(.3);cs.paragraph_format.space_before=Pt(3);cs.paragraph_format.space_after=Pt(5)
# header/footer
for s in doc.sections:
    hp=s.header.paragraphs[0];hp.text='DIKWP-MESH 5.9 MONOGENESIS DECISOR v5.0.0';hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    for r in hp.runs:set_run_font(r,8,color=(95,112,130))
    add_page_num(s.footer.paragraphs[0])

def para(text='',bold_lead=None,style=None,align=None):
    p=doc.add_paragraph(style=style)
    if align:p.alignment=align
    if bold_lead and text.startswith(bold_lead):
        r=p.add_run(bold_lead);set_run_font(r,bold=True);r2=p.add_run(text[len(bold_lead):]);set_run_font(r2)
    else:
        r=p.add_run(text);set_run_font(r)
    return p

def bullet(text,level=0):
    p=doc.add_paragraph(style='List Bullet' if level==0 else 'List Bullet 2');r=p.add_run(text);set_run_font(r);return p

def numbered(text):
    p=doc.add_paragraph(style='List Number');r=p.add_run(text);set_run_font(r);return p

def callout(title,text,fill='E8F2F8'):
    t=doc.add_table(rows=1,cols=1);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=True;c=t.cell(0,0);shade(c,fill);margins(c,130,150,130,150)
    p=c.paragraphs[0];r=p.add_run(title+'\n');set_run_font(r,10.5,True,(12,65,98));r2=p.add_run(text);set_run_font(r2,9.5)
    doc.add_paragraph('')

def image(fn,caption,width=6.25):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.add_run().add_picture(str(ROOT/'reports/assets'/fn),width=Inches(width))
    cp=doc.add_paragraph();cp.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=cp.add_run(caption);set_run_font(r,8.5,color=(80,95,110))

# Cover
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.space_before=Pt(70)
r=p.add_run('DIKWP-MESH 5.9\nMONOGENESIS DECISOR');set_run_font(r,28,True,(10,48,82))
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run('全命题极性决断、七个千禧年问题证明战役\n与可复核语义数学系统');set_run_font(r,18,True,(35,104,137))
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run('Comprehensive Report on Determinate Polarity, Millennium Proof Campaigns,\nand Falsifiable Semantic Mathematics');set_run_font(r,12,False,(70,90,110))
doc.add_paragraph('')
image('fig1_architecture.png','封面图：从单一续生关系到可审计极性包',5.8)
callout('发行状态 / Release status',f"Version 5.0.0 | Evidence E2 author-side deterministic reference | Run hash {RUN['run_hash']}",'DDECF4')
p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;r=p.add_run('2026-07-28');set_run_font(r,10,color=(80,95,110))

# Executive boundary
h=doc.add_heading('摘要与结论边界 / Abstract and Claim Boundary',level=1)
para('本报告回应“让包括七个千禧年问题在内的全部注册命题获得确定、可复核的真／假解决”的要求。系统对36个精确命题全部给出 TRUE 或 FALSE：33个 TRUE、3个 FALSE，无 UNKNOWN。与此同时，报告拒绝把这种有限注册表上的语义极性赋值伪装成六个仍开放千禧年问题已经获得外部数学证明。')
para('The system assigns a determinate polarity to every proposition in its finite registry, while separating established certificates from falsifiable semantic candidates. It therefore delivers total candidate polarity without claiming an impossible universal truth oracle or unverified Millennium theorems.')
callout('最重要的双层结论','层一：每个命题都有唯一、可复算、可撤销的研究极性。层二：只有已核验证明或同对象反例才进入 ESTABLISHED；其余必须保留 SEMANTIC_CANDIDATE。')
para('附件《SEMANTIC GENESIS 5.9》为本系统提供了四项源纪律：不赋予标准数学或反标准叙事唯一终审权；将“证明”拆分为不同完成关系；禁止有限接触无痕升级为无限全称；允许规则被对象化并继续开放。附件并未给出本报告的36项极性，也没有宣称六个开放千禧年问题已获最终证明；这些极性与决定性引理属于本次独立扩展。')
image('fig2_status_distribution.png','图1 36个命题的证据状态分布')

# TOC-like
h=doc.add_heading('目录 / Contents',level=1)
for x in ['一、问题重构：何谓“全部命题确定为真或假”','二、来源继承与独立扩展','三、单一续生本体与精确命题地址','四、极性比较器、稳定性与不可能性边界','五、七个千禧年问题的逐项证明战役','六、36命题极性总表','七、27项实际运行实验','八、开放源码系统与验证','九、最终结论与传播纪律']:
    para(x)
doc.add_page_break()

# Sections
h=doc.add_heading('一、问题重构：何谓“全部命题确定为真或假”',level=1)
para('若“全部命题已解决”被理解为把任意命题及其否定都盖章为真，系统将失去区分能力；若被理解为存在一个对全部算术句子都可靠、总停机且有效的真值程序，又会触及自指与不可判定边界。因此，本系统采用更严格的双层制度。')
bullet('语义决断层：有限注册表中的每个精确命题必须获得 TRUE 或 FALSE 候选极性。')
bullet('证明证书层：只有可核验的证明对象或同对象反例才能把候选升级为已建立结论。')
bullet('证明战役层：尚无证书者必须具有决定性引理、完整证明程序、反世界和 Kill Tests。')
para('这种制度没有把 UNKNOWN 留作空白；它把未知转化为可攻击的候选极性和最小决定性义务。同时，它也不会把“研究者必须押注一个方向”偷换成“该方向已成为定理”。')

h=doc.add_heading('二、来源继承与独立扩展',level=1)
para('《SEMANTIC GENESIS 5.9》第3页提出独立立场：既不站队标准数学主流，也不把纯语义叙事封为新权威。第9页的十二条宪约要求概念具有发生谱系、Purpose 不具绝对特权、局部闭合携带重开条件。第12页把证明拆分为发生、局部必然、世界接触、相互理解、非坍塌和形式投影。第16页明确把 Goldbach 的难点定位为加法完整与乘法原子之间的跨算子桥；第18页要求把语义约束发现成本计入 P/NP；第19-20页拒绝最终全知元语言；第26页把奥卡姆剃刀改写为最少未经生成原语。')
para('本版本继承上述纪律，但作出独立扩展：公开一个候选极性比较器，为所有36项命题规定唯一研究方向，并对七个千禧年问题提出可被直接证伪的决定性引理。')
callout('来源边界','附件支持方法约束，不支持“六个开放千禧年问题已被证明”的结论。任何传播都必须保留这一差别。','FFF2CC')

h=doc.add_heading('三、单一续生本体与精确命题地址',level=1)
para('唯一原语是 h -> h\'，即当前历史可以续生为后继历史。对象、概念、命题、证明和反例都是续生历史的稳定地址。系统不再预设 D、I、K、W、P 或额外九元组为本体粒子；这些只是在不同任务中的派生角色。')
para('传统命题进入系统时必须冻结六类信息：对象类型、量词域、运算关系、精度、资源模型、见证与反例形态。改变任一项即生成新命题，不能继续沿用旧问题名称。')
image('fig6_unified_millennium.png','图2 七个千禧年问题共享的局部-全局续生骨架')

h=doc.add_heading('四、极性比较器、稳定性与不可能性边界',level=1)
para('在没有决定性证书时，系统使用公开的最小余量比较器。特征向量包括证书、有限接触、续生相容、机制、反世界平衡、统一化支持和资源诚实；权重依次为 8.0、0.75、1.5、1.35、1.1、0.8、1.0。分数非负得到 TRUE 候选，负值得到 FALSE 候选。')
para('证书权重具有支配作用：已核验证明强制 TRUE；对全称命题的同对象反例强制 FALSE。其余特征是公开研究判断，允许被外部团队重估。')
para('系统分别报告权重扰动稳定性和权重+特征联合扰动稳定性。两者测量规范敏感度，不是定理真值概率。“confidence-index”同样只是分数边际显示。')
image('fig3_millennium_scores.png','图3 七个千禧年问题的发行基线极性分数')
image('fig4_millennium_stability.png','图4 七项极性的权重与联合不确定性敏感度')
image('fig5_millennium_features.png','图5 七项公开特征向量')
callout('不可省略的元边界','不存在一个同时一致、有效、对足够丰富算术有表达力、并对所有句子可靠总决断的固定程序。因此本系统的“全决断”限于有限注册表上的候选极性，而不是全数学语言的全知真值机。')

# Millennium details
h=doc.add_heading('五、七个千禧年问题的逐项证明战役',level=1)
for idx,m in enumerate(M,1):
    x=BY[m['problem_id']]
    doc.add_heading(f"5.{idx} {x['name_cn']} / {x['name_en']}",level=2)
    table=doc.add_table(rows=0,cols=2);table.alignment=WD_TABLE_ALIGNMENT.CENTER;table.style='Table Grid'
    for k,v in [('精确命题',m['exact_proposition']),('发行极性',m['candidate_verdict']),('状态',x['proof_status']),('极性分数',x['score']),('联合稳定性',f"{x['joint_stability']:.3f}"),('续生归约',m['continuation_reduction']),('决定性引理',m['decisive_lemma']),('反世界',x['counterworld'])]:
        cells=table.add_row().cells;set_cell_text(cells[0],k,8.5,True);shade(cells[0],'E5EEF5');set_cell_text(cells[1],v,8.5)
    para('证明程序：',bold_lead='证明程序：')
    for z in m['proof_program']:numbered(z)
    para('已知障碍：',bold_lead='已知障碍：')
    for z in m['known_barriers']:bullet(z)
    para('证伪与撤销条件：',bold_lead='证伪与撤销条件：')
    for z in m['falsification_tests']:bullet(z)
    callout('证据边界',m['evidence_boundary'],'F8E7D2' if m['official_status']=='OPEN' else 'DFF3E7')
    if idx in (2,4,6):doc.add_page_break()

# 36 table
h=doc.add_heading('六、36命题极性总表',level=1)
para('下表给出系统的确定极性。TRUE/FALSE 是命题方向；“已建立/语义候选”才是证据等级。为了保持可读性，36项分成两张表。')
for chunk_i in range(0,len(P),18):
    table=doc.add_table(rows=1,cols=6);table.style='Table Grid';table.alignment=WD_TABLE_ALIGNMENT.CENTER
    headers=['问题','极性','证据状态','分数','联合稳定性','决定性引理（摘要）']
    for i,hx in enumerate(headers):set_cell_text(table.rows[0].cells[i],hx,7.4,True,(255,255,255));shade(table.rows[0].cells[i],'1D5D7A')
    set_repeat_table_header(table.rows[0])
    for x in P[chunk_i:chunk_i+18]:
        c=table.add_row().cells
        vals=[x['name_cn']+'\n'+x['name_en'],x['verdict_label'],x['proof_status'],f"{x['score']:.3f}",f"{x['joint_stability']:.3f}",x['decisive_lemma']]
        for i,v in enumerate(vals):set_cell_text(c[i],v,6.8 if i in (0,5) else 7.2,bold=(i==1),color=((25,135,75) if i==1 and v=='TRUE' else ((185,40,55) if i==1 else None)))
    doc.add_paragraph('')

# Experiments
h=doc.add_heading('七、27项实际运行实验',level=1)
para('27项实验用于世界接触、代码路径验证和反世界搜索。它们不替代无界全称证明。每份回执都包含参数、指标、局部结论和禁止升级的全局推论。')
# summary table all experiments
T=doc.add_table(rows=1,cols=4);T.style='Table Grid';T.alignment=WD_TABLE_ALIGNMENT.CENTER
for i,hx in enumerate(['问题','实验类型','状态','主要指标/禁止推论']):set_cell_text(T.rows[0].cells[i],hx,7.5,True,(255,255,255));shade(T.rows[0].cells[i],'1D5D7A')
set_repeat_table_header(T.rows[0])
for e in EXP:
    c=T.add_row().cells;metrics=', '.join(f"{k}={v}" for k,v in list(e['metrics'].items())[:3]);vals=[e['problem_id'],e['experiment_kind'],e['status'],metrics+'\n禁止：'+e['prohibited_global_inference']]
    for i,v in enumerate(vals):set_cell_text(c[i],v,6.7)

h=doc.add_heading('八、开放源码系统与验证',level=1)
para('开源系统包含：36问题图册、极性比较器、七题证明战役包、27项实验、14项元定理、哈希链证据账本、六类JSON Schema、离线驾驶舱和权重敏感度工作台。')
for z in ['源码测试与状态边界检查','两次参考运行哈希一致','JSON Schema制品验证','wheel/source distribution/zipapp 构建与安装复验','归档Manifest和SHA-256复验','DOCX/PDF逐页渲染检查与可访问性审计']:
    bullet(z)
para('参考运行核心标识：')
para(f"Run hash: {RUN['run_hash']}",style='CodeBlock')
para(f"Ledger head: {RUN['ledger']['verification']['head']}",style='CodeBlock')

h=doc.add_heading('九、最终结论与传播纪律',level=1)
para('本次实现了用户要求中可以在不破坏可复核性的前提下达到的最强形式：36项命题全部获得唯一 TRUE/FALSE 极性；七个千禧年问题全部获得逐步证明战役包；没有任何开放问题停留在没有坐标的 UNKNOWN。')
para('同时，系统没有伪造“六个开放千禧年问题已被数学上证明”。发行基线为：P=NP 取 FALSE 候选，即 P≠NP；RH、BSD、Hodge、三维 Navier-Stokes 整体正则和 Yang-Mills 质量间隙取 TRUE 候选；庞加莱猜想为已建立 TRUE。')
callout('最终判断','这是“全部命题获得确定研究极性”的系统，不是“全部候选已经成为定理”的系统。真正的最终求解将在决定性引理被证明或同对象反世界被构造时发生；届时系统会以证书而不是权威升级状态。','DDECF4')

h=doc.add_heading('参考资料 / References',level=1)
refs=[
'1. 《SEMANTIC GENESIS 5.9：语义发生、概念诞生、理解耦合证明与跨 DIKWP 必然性计算系统》，用户提供附件，2026-07-27。',
'2. Clay Mathematics Institute, Millennium Prize Problems and individual problem descriptions, status snapshot used on 2026-07-28.',
'3. Perelman/Ricci-flow literature for the Poincare theorem.',
'4. DIKWP-MESH 5.9 MONOGENESIS ONE v3.0.0 and TOTALIS v4.0.0, prior author-side reference systems.',
'5. D-MATH GENESIS Omega-Infinity v2.0.0, problem atlas and 27 experimental baselines.',
'6. This release: polarity registry, Millennium resolution packets, experiment receipts and evidence ledger.'
]
for x in refs:para(x)

# Save
OUT.parent.mkdir(parents=True,exist_ok=True);doc.save(OUT);print(OUT)
