from pathlib import Path
import json
from collections import Counter
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'reports/assets';OUT.mkdir(parents=True,exist_ok=True)
run=json.load(open(ROOT/'outputs/reference/reference_run.json',encoding='utf-8'));P=run['polarity']['packets'];mills={x['problem_id'] for x in run['millennium']['packets']}
# Architecture
fig=plt.figure(figsize=(11,6.5));ax=fig.add_axes([0,0,1,1]);ax.axis('off')
boxes=[(.04,.70,.19,.15,'One primitive\nCAN_CONTINUE_AS'),(.28,.70,.20,.15,'Exact proposition\nobject / quantifier / cost'),(.53,.70,.19,.15,'Dual continuations\nphi / not-phi'),(.77,.70,.19,.15,'Certificate priority\nproof / counterexample'),(.16,.36,.22,.16,'27 contact experiments\nfinite / symbolic / numeric'),(.42,.36,.22,.16,'Least-residual comparator\npublic features and weights'),(.68,.36,.22,.16,'Decisive lemma\ncounterworld / kill tests'),(.39,.07,.25,.17,'Polarity packet\nTRUE / FALSE\nestablished or candidate')]
for x,y,w,h,t in boxes: ax.add_patch(plt.Rectangle((x,y),w,h,fill=False,linewidth=2));ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=11)
for a,b in [((.23,.775),(.28,.775)),((.48,.775),(.53,.775)),((.72,.775),(.77,.775)),((.38,.70),(.27,.52)),((.62,.70),(.53,.52)),((.86,.70),(.79,.52)),((.38,.44),(.42,.44)),((.64,.44),(.68,.44)),((.53,.36),(.51,.24)),((.79,.36),(.61,.24))]:ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->',lw=1.7))
ax.text(.5,.95,'MONOGENESIS DECISOR: from continuation to auditable polarity packets',ha='center',fontsize=18,fontweight='bold')
fig.savefig(OUT/'fig1_architecture.png',dpi=180,bbox_inches='tight');plt.close(fig)
# Status
c=Counter(x['proof_status'] for x in P);fig,ax=plt.subplots(figsize=(9,5.4));names=list(c);vals=[c[x] for x in names];ax.bar(range(len(names)),vals);ax.set_xticks(range(len(names)),[x.replace('_','\n') for x in names]);ax.set_ylabel('Number of propositions');ax.set_title('36 propositions: established results and semantic candidates');[ax.text(i,v+.2,str(v),ha='center') for i,v in enumerate(vals)];fig.tight_layout();fig.savefig(OUT/'fig2_status_distribution.png',dpi=180);plt.close(fig)
mp=[x for x in P if x['problem_id'] in mills];labels=[x['name_en'] for x in mp];xx=np.arange(len(mp))
fig,ax=plt.subplots(figsize=(10.5,6));scores=[x['score'] for x in mp];ax.bar(xx,scores);ax.axhline(0,linewidth=1);ax.set_xticks(xx,labels,rotation=28,ha='right');ax.set_ylabel('Polarity score (+ TRUE, - FALSE)');ax.set_title('Millennium problems: release-baseline candidate polarity');[ax.text(i,v+(.15 if v>=0 else -.40),f'{v:.2f}',ha='center',fontsize=9) for i,v in enumerate(scores)];fig.tight_layout();fig.savefig(OUT/'fig3_millennium_scores.png',dpi=180);plt.close(fig)
fig,ax=plt.subplots(figsize=(10.5,6));ws=[100*x['weight_stability'] for x in mp];js=[100*x['joint_stability'] for x in mp];w=.36;ax.bar(xx-w/2,ws,w,label='weights only');ax.bar(xx+w/2,js,w,label='weights + feature uncertainty');ax.set_ylim(0,105);ax.set_xticks(xx,labels,rotation=28,ha='right');ax.set_ylabel('Polarity retained (%)');ax.set_title('Millennium candidate sensitivity');ax.legend();fig.tight_layout();fig.savefig(OUT/'fig4_millennium_stability.png',dpi=180);plt.close(fig)
keys=list(run['polarity']['weights']);arr=np.array([[x['features'][k] for k in keys] for x in mp]);fig,ax=plt.subplots(figsize=(11.5,6.2));im=ax.imshow(arr,aspect='auto',vmin=-1,vmax=1);ax.set_xticks(range(len(keys)),[k.replace('_','\n') for k in keys],rotation=25,ha='right');ax.set_yticks(range(len(mp)),labels);ax.set_title('Public feature vectors (-1 supports FALSE; +1 supports TRUE)');fig.colorbar(im,ax=ax)
for i in range(arr.shape[0]):
 for j in range(arr.shape[1]):ax.text(j,i,f'{arr[i,j]:.2f}',ha='center',va='center',fontsize=8)
fig.tight_layout();fig.savefig(OUT/'fig5_millennium_features.png',dpi=180);plt.close(fig)
fig=plt.figure(figsize=(11,6.5));ax=fig.add_axes([0,0,1,1]);ax.axis('off');ax.text(.5,.93,'Shared skeleton: local continuation is not global zero residual',ha='center',fontsize=18,fontweight='bold');ax.add_patch(plt.Circle((.5,.5),.13,fill=False,linewidth=2));ax.text(.5,.5,'Globally compatible\ncontinuation\n+ honest resources\n+ zero residual',ha='center',va='center',fontsize=12)
for name,x,y,sub in [('P vs NP',.12,.72,'uniform selector'),('Riemann',.37,.80,'spectral positivity'),('BSD',.66,.80,'local-global rank'),('Hodge',.88,.66,'algebraization'),('Navier-Stokes',.82,.28,'scale regularity'),('Yang-Mills',.52,.16,'limit and gap'),('Poincare',.18,.28,'flow and topology')]:ax.add_patch(plt.Rectangle((x-.09,y-.055),.18,.11,fill=False,linewidth=1.6));ax.text(x,y,f'{name}\n{sub}',ha='center',va='center',fontsize=10.5);ax.annotate('',xy=(.5,.5),xytext=(x,y),arrowprops=dict(arrowstyle='->',lw=1.2))
fig.savefig(OUT/'fig6_unified_millennium.png',dpi=180,bbox_inches='tight');plt.close(fig)
print('generated',len(list(OUT.glob('fig*.png'))))
