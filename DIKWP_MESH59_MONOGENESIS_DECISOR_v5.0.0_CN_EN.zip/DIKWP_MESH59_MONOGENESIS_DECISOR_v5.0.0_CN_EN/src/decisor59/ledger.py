from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from .canonical import sha256_obj

@dataclass(frozen=True)
class LedgerRecord:
    sequence: int
    kind: str
    payload: dict[str,Any]
    payload_hash: str
    previous_hash: str
    record_hash: str

class EvidenceLedger:
    def __init__(self): self.records:list[LedgerRecord]=[]
    def append(self,kind:str,payload:dict[str,Any]):
        seq=len(self.records);prev=self.records[-1].record_hash if self.records else '0'*64
        ph=sha256_obj(payload);rh=sha256_obj({'sequence':seq,'kind':kind,'payload_hash':ph,'previous_hash':prev})
        self.records.append(LedgerRecord(seq,kind,payload,ph,prev,rh));return rh
    def verify(self):
        prev='0'*64
        for i,r in enumerate(self.records):
            if r.sequence!=i or r.previous_hash!=prev or r.payload_hash!=sha256_obj(r.payload):
                return {'valid':False,'count':len(self.records),'first_invalid':i,'head':prev}
            expected=sha256_obj({'sequence':i,'kind':r.kind,'payload_hash':r.payload_hash,'previous_hash':prev})
            if r.record_hash!=expected:return {'valid':False,'count':len(self.records),'first_invalid':i,'head':prev}
            prev=r.record_hash
        return {'valid':True,'count':len(self.records),'first_invalid':None,'head':prev}
    def to_dict(self):
        return {'schema':'MONOGENESIS_DECISOR_EVIDENCE_LEDGER_V1','records':[asdict(r) for r in self.records],'verification':self.verify()}
