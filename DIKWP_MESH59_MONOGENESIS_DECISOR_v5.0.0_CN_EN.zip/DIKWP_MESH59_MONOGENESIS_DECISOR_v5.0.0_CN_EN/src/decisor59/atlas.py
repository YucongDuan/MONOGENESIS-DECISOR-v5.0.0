from __future__ import annotations
import json
from importlib import resources

def load_atlas():
    return json.loads(resources.files('decisor59.data').joinpath('problem_atlas.json').read_text(encoding='utf-8'))
