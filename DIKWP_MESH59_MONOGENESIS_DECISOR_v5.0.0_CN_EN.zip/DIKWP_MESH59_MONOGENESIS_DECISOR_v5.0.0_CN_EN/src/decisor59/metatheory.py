from __future__ import annotations
from .canonical import sha256_obj

def theorem_registry()->dict:
    rows=[
      ('M1','单一续生原语','Every registered object is represented through CAN_CONTINUE_AS; labels are derived addresses, not additional ontology.'),
      ('M2','极性互补','For one fixed normalized proposition, the comparator assigns exactly one of TRUE or FALSE; its syntactic negation receives the opposite candidate polarity.'),
      ('M3','决定性证书支配','A verified proof certificate forces TRUE; a verified same-object counterexample to a universal proposition forces FALSE.'),
      ('M4','候选可撤销','New same-object evidence can reverse a semantic candidate; Purpose and author authority cannot immunize it.'),
      ('M5','有限接触屏障','Finite verification contributes local evidence but cannot alone become an unbounded certificate.'),
      ('M6','最小余量比较','Without a decisive certificate, the system selects the lower weighted continuation residual and discloses every feature and weight.'),
      ('M7','稳定性非概率','Weight and joint stability measure comparator sensitivity; neither is a probability that a theorem is true.'),
      ('M8','无全能有效真值机','No consistent effective system sufficiently expressive for arithmetic can be a sound total decider for every sentence; finite-registry totality is candidate assignment, not omniscience.'),
      ('M9','七题同源归约','The seven Millennium problems admit a shared local-to-global continuation skeleton, while their decisive bridges remain problem-specific.'),
      ('M10','传统命题地址保持','The normalized proposition preserves objects, quantifier domains, operations and resource model; changing any creates a different packet.'),
      ('M11','候选不冒充定理','SEMANTIC_CANDIDATE_TRUE/FALSE is a falsifiable research verdict, not an established theorem.'),
      ('M12','有限注册表全赋极','Every entry in the finite atlas receives a deterministic polarity, decisive lemma, counterworld and kill tests.'),
      ('M13','源材料边界','Semantic Genesis 5.9 supports non-monopoly, proof-type separation, finite-contact discipline and open reflection; it does not supply the candidate polarities in this release.'),
      ('M14','证明战役可复核','A proof campaign is complete as a research object when its exact proposition, decisive lemma, barriers, proof program and falsification tests are content-addressed.'),
    ]
    out=[]
    for tid,cn,st in rows:
        x={'theorem_id':tid,'title_cn':cn,'statement':st,'status':'PROVED_BY_CONSTRUCTION_OR_STANDARD_METATHEORY'};x['hash']=sha256_obj(x);out.append(x)
    return {'schema':'DECISOR_META_THEOREM_REGISTRY_V1','count':len(out),'theorems':out}
