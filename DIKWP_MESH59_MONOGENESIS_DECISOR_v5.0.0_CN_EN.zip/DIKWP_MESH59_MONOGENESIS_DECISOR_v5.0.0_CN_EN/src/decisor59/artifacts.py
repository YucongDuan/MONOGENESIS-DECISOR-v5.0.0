from __future__ import annotations

import json
import re
from importlib import resources
from pathlib import Path
from typing import Any

FILES = {
    "reference_run.json": "reference_run.schema.json",
    "polarity_registry.json": "polarity_registry.schema.json",
    "millennium_resolution_packets.json": "millennium_registry.schema.json",
    "metatheorem_registry.json": "metatheorem_registry.schema.json",
    "experiment_receipts.json": "experiment_receipts.schema.json",
    "evidence_ledger.json": "evidence_ledger.schema.json",
}


class SchemaValidationError(ValueError):
    """Raised by the dependency-free schema subset validator."""


def _matches_type(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return True


def _validate_subset(value: Any, schema: dict[str, Any], path: str = "$") -> None:
    """Validate the JSON-Schema constructs used by this release.

    Supported keywords: type, const, enum, required, properties, items,
    minItems, maxItems, minimum, maximum and pattern.  The release schemas
    intentionally stay inside this auditable subset so installed wheels do
    not require a third-party validator merely to verify their own artifacts.
    """

    if "type" in schema and not _matches_type(value, schema["type"]):
        raise SchemaValidationError(f"{path}: expected type {schema['type']}")
    if "const" in schema and value != schema["const"]:
        raise SchemaValidationError(f"{path}: expected const {schema['const']!r}")
    if "enum" in schema and value not in schema["enum"]:
        raise SchemaValidationError(f"{path}: value not in enum")

    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                raise SchemaValidationError(f"{path}: missing required key {key!r}")
        for key, child_schema in schema.get("properties", {}).items():
            if key in value:
                _validate_subset(value[key], child_schema, f"{path}.{key}")

    if isinstance(value, list):
        if "minItems" in schema and len(value) < int(schema["minItems"]):
            raise SchemaValidationError(f"{path}: fewer than minItems")
        if "maxItems" in schema and len(value) > int(schema["maxItems"]):
            raise SchemaValidationError(f"{path}: more than maxItems")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for i, item in enumerate(value):
                _validate_subset(item, item_schema, f"{path}[{i}]")

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            raise SchemaValidationError(f"{path}: below minimum")
        if "maximum" in schema and value > schema["maximum"]:
            raise SchemaValidationError(f"{path}: above maximum")

    if isinstance(value, str) and "pattern" in schema:
        if re.search(schema["pattern"], value) is None:
            raise SchemaValidationError(f"{path}: does not match pattern")


def _validate(obj: Any, schema: dict[str, Any]) -> str:
    """Use jsonschema when present; otherwise use the packaged subset."""
    try:
        import jsonschema  # type: ignore
    except ModuleNotFoundError:
        _validate_subset(obj, schema)
        return "builtin-schema-subset"
    jsonschema.Draft202012Validator(schema).validate(obj)
    return "jsonschema-draft-2020-12"


def validate_artifacts(root: str | Path) -> dict[str, Any]:
    root = Path(root)
    checks: list[dict[str, Any]] = []
    for filename, schema_name in FILES.items():
        artifact_path = root / filename
        row: dict[str, Any] = {
            "file": filename,
            "schema_file": schema_name,
            "exists": artifact_path.is_file(),
            "passed": False,
            "validator": None,
            "detail": "",
        }
        try:
            obj = json.loads(artifact_path.read_text(encoding="utf-8"))
            schema = json.loads(
                resources.files("decisor59.data.schemas")
                .joinpath(schema_name)
                .read_text(encoding="utf-8")
            )
            row["validator"] = _validate(obj, schema)
            row["passed"] = True
        except Exception as exc:  # fail closed and expose the exact defect
            row["detail"] = f"{type(exc).__name__}: {exc}"
        checks.append(row)
    passed = sum(bool(item["passed"]) for item in checks)
    return {
        "schema": "MONOGENESIS_DECISOR_ARTIFACT_VALIDATION_V1",
        "total": len(checks),
        "passed": passed,
        "failed": len(checks) - passed,
        "all_passed": all(bool(item["passed"]) for item in checks),
        "checks": checks,
    }
