from __future__ import annotations
import argparse,json
from . import __version__
from .demo import run_demo
from .conformance import run_conformance
from .polarity import compile_polarity_registry
from .millennium import registry as millennium_registry
from .canonical import write_json
from .artifacts import validate_artifacts

def main(argv=None)->int:
    p=argparse.ArgumentParser(prog='decisor59',description='DIKWP-MESH 5.9 MONOGENESIS DECISOR')
    p.add_argument('--version',action='version',version=__version__);sub=p.add_subparsers(dest='cmd',required=True)
    d=sub.add_parser('demo');d.add_argument('--out',default='outputs/demo');d.add_argument('--skip-experiments',action='store_true')
    c=sub.add_parser('conformance');c.add_argument('--out',default='outputs/conformance.json')
    r=sub.add_parser('polarity');r.add_argument('--out',default='outputs/polarity.json')
    m=sub.add_parser('millennium');m.add_argument('--out',default='outputs/millennium.json')
    v=sub.add_parser('artifacts-validate');v.add_argument('--root',default='outputs/reference');v.add_argument('--out',default='outputs/artifact-validation.json')
    a=p.parse_args(argv)
    if a.cmd=='demo':print(json.dumps(run_demo(a.out,not a.skip_experiments),ensure_ascii=False,indent=2));return 0
    if a.cmd=='conformance':
        x=run_conformance();write_json(a.out,x);print(f"{x['passed']}/{x['total']}");return 0 if x['all_passed'] else 1
    if a.cmd=='polarity':write_json(a.out,compile_polarity_registry([]));return 0
    if a.cmd=='millennium':write_json(a.out,millennium_registry());return 0
    if a.cmd=='artifacts-validate':
        x=validate_artifacts(a.root);write_json(a.out,x);print(f"{x['passed']}/{x['total']}");return 0 if x['all_passed'] else 1
    return 2
