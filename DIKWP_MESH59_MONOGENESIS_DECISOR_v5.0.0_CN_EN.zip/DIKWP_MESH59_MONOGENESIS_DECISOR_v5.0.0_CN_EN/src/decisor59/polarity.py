from __future__ import annotations
import json, math, random
from importlib import resources
from typing import Any
from .atlas import load_atlas
from .models import PolarityPacket
from .canonical import sha256_obj

def load_priors() -> dict[str,Any]:
    return json.loads(resources.files('decisor59.data').joinpath('polarity_priors.json').read_text(encoding='utf-8'))

def _score(features:dict[str,float],weights:dict[str,float])->float:
    return sum(float(features[k])*float(weights[k]) for k in weights)

def _confidence_index(score:float)->float:
    # Comparator margin index only. It is intentionally not called a probability.
    return round(0.5 + 0.499*math.tanh(abs(score)/4.0),6)

def _stability(problem_id:str,features:dict[str,float],weights:dict[str,float],samples:int=4000,joint:bool=False)->float:
    seed=int(sha256_obj({'problem_id':problem_id,'joint':joint})[:16],16)
    rng=random.Random(seed);base=_score(features,weights)>=0;same=0
    keys=list(weights)
    for _ in range(samples):
        pert_w={k:weights[k]*(1+rng.uniform(-0.25,0.25)) for k in keys}
        if joint:
            # Feature uncertainty is intentionally wider than weight uncertainty.
            pert_f={k:max(-1.0,min(1.0,features[k]+rng.uniform(-0.35,0.35))) for k in keys}
        else: pert_f=features
        if (_score(pert_f,pert_w)>=0)==base:same+=1
    return round(same/samples,6)

def compile_polarity_registry(experiment_receipts:list[dict[str,Any]]|None=None)->dict[str,Any]:
    atlas=load_atlas();pri=load_priors();weights=pri['weights'];by={x['problem_id']:x for x in pri['problems']}
    exp_by={x['problem_id']:x for x in (experiment_receipts or [])};packets=[]
    for p in atlas['problems']:
        x=by[p['problem_id']];features=x['features'];score=_score(features,weights);truth=score>=0
        if truth != bool(x['candidate_truth']): raise ValueError(f"score/polarity mismatch for {p['problem_id']}: {score}")
        cert=features['certificate']
        status=(('ESTABLISHED_TRUE' if truth else 'ESTABLISHED_FALSE') if abs(cert)>=0.999
                else ('SEMANTIC_CANDIDATE_TRUE' if truth else 'SEMANTIC_CANDIDATE_FALSE'))
        exp=exp_by.get(p['problem_id']);refs=[]
        if exp: refs.append(exp.get('receipt_hash',''))
        packet=PolarityPacket(
            problem_id=p['problem_id'],name_cn=p['name_cn'],name_en=p['name_en'],normalized_proposition=x['normalized_proposition'],
            candidate_truth=truth,verdict_label='TRUE' if truth else 'FALSE',proof_status=status,score=round(score,6),
            weight_stability=_stability(p['problem_id'],features,weights,joint=False),
            joint_stability=_stability(p['problem_id'],features,weights,joint=True),confidence_index=_confidence_index(score),
            features=features,decisive_lemma=x['decisive_lemma'],proof_program=x['proof_program'],counterworld=x['counterworld'],
            kill_tests=x['kill_tests'],local_evidence_refs=refs,source_refs=p.get('source_refs',[]),limitations=x['limitations'])
        packets.append(packet.to_dict())
    counts={}
    for q in packets:counts[q['proof_status']]=counts.get(q['proof_status'],0)+1
    obj={'schema':'MONOGENESIS_DECISOR_POLARITY_REGISTRY_V1','as_of':'2026-07-28','primitive':'CAN_CONTINUE_AS',
         'decision_rule':'proof/counterexample certificates dominate; otherwise a public least-residual continuation comparator assigns a falsifiable semantic candidate polarity',
         'weights':weights,'packet_count':len(packets),'status_counts':counts,'true_count':sum(q['candidate_truth'] for q in packets),
         'false_count':sum(not q['candidate_truth'] for q in packets),'no_unknown':all(q['verdict_label'] in ('TRUE','FALSE') for q in packets),
         'interpretation':{'weight_stability':'fraction retaining polarity under +/-25% weight perturbation',
                           'joint_stability':'fraction retaining polarity under weight and +/-0.35 feature perturbation',
                           'confidence_index':'score-margin display index; not probability of mathematical truth'},
         'packets':packets}
    obj['registry_hash']=sha256_obj(obj);return obj
