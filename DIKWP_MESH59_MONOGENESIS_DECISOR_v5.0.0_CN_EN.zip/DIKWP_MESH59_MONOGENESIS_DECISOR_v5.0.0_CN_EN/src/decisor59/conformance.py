from __future__ import annotations
from copy import deepcopy
from .polarity import compile_polarity_registry,load_priors
from .millennium import registry as millennium_registry
from .metatheory import theorem_registry
from .atlas import load_atlas
from .ledger import EvidenceLedger

def run_conformance()->dict:
    checks=[]
    def ck(name,cond,detail=''):checks.append({'name':name,'passed':bool(cond),'detail':detail})
    atlas=load_atlas();pri=load_priors();reg=compile_polarity_registry([]);mill=millennium_registry();meta=theorem_registry()
    ck('atlas has 36 problems',len(atlas['problems'])==36);ck('priors have 36 problems',len(pri['problems'])==36)
    ck('unique problem ids',len({p['problem_id'] for p in atlas['problems']})==36);ck('registry has 36 packets',reg['packet_count']==36)
    ck('no unknown polarities',reg['no_unknown']);ck('true plus false equals 36',reg['true_count']+reg['false_count']==36);ck('three false candidates',reg['false_count']==3)
    ck('seven millennium packets',mill['count']==7);ck('poincare established true',next(p for p in reg['packets'] if p['problem_id']=='poincare')['proof_status']=='ESTABLISHED_TRUE')
    ck('P=NP candidate false',next(p for p in reg['packets'] if p['problem_id']=='p-vs-np')['candidate_truth'] is False)
    ck('RH candidate true',next(p for p in reg['packets'] if p['problem_id']=='riemann-hypothesis')['candidate_truth'] is True)
    ck('odd perfect existence candidate false',next(p for p in reg['packets'] if p['problem_id']=='odd-perfect-number')['candidate_truth'] is False)
    ck('perfect cuboid existence candidate false',next(p for p in reg['packets'] if p['problem_id']=='perfect-cuboid')['candidate_truth'] is False)
    ck('Jacobian >=3 counterworld proposition established',next(p for p in reg['packets'] if p['problem_id']=='jacobian-nge3')['proof_status']=='ESTABLISHED_TRUE')
    ck('all packets have decisive lemmas',all(p['decisive_lemma'] for p in reg['packets']));ck('all packets have proof programs',all(p['proof_program'] for p in reg['packets']))
    ck('all candidates have kill tests',all(p['kill_tests'] for p in reg['packets']));ck('all feature keys match weights',all(set(p['features'])==set(reg['weights']) for p in reg['packets']))
    ck('weight stability in range',all(0<=p['weight_stability']<=1 for p in reg['packets']));ck('joint stability in range',all(0<=p['joint_stability']<=1 for p in reg['packets']))
    ck('confidence indices in range',all(.5<=p['confidence_index']<1 for p in reg['packets']));ck('fourteen metatheorems',meta['count']==14)
    ck('candidate status not established',all(not p['proof_status'].startswith('ESTABLISHED') for p in reg['packets'] if abs(p['features']['certificate'])<.999))
    led=EvidenceLedger();led.append('registry',reg);led.append('millennium',mill);ck('ledger verifies',led.verify()['valid'])
    bad=deepcopy(led);object.__setattr__(bad.records[0],'payload',{'tampered':True});ck('ledger detects tamper',not bad.verify()['valid'])
    passed=sum(c['passed'] for c in checks)
    return {'schema':'MONOGENESIS_DECISOR_CONFORMANCE_V1','total':len(checks),'passed':passed,'failed':len(checks)-passed,'all_passed':passed==len(checks),'checks':checks}
