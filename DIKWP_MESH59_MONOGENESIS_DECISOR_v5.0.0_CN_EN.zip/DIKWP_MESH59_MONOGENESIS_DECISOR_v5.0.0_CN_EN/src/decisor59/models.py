from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
from .canonical import sha256_obj

@dataclass(frozen=True)
class ExperimentReceipt:
    receipt_id: str
    problem_id: str
    experiment_kind: str
    parameters: dict[str, Any]
    metrics: dict[str, Any]
    observations: list[str]
    local_claim: str
    prohibited_global_inference: str
    status: str
    started_at: str
    completed_at: str
    code_hash: str
    receipt_hash: str = ''
    def to_dict(self): return asdict(self)

@dataclass(frozen=True)
class PolarityPacket:
    problem_id: str
    name_cn: str
    name_en: str
    normalized_proposition: str
    candidate_truth: bool
    verdict_label: str
    proof_status: str
    score: float
    weight_stability: float
    joint_stability: float
    confidence_index: float
    features: dict[str,float]
    decisive_lemma: str
    proof_program: list[str]
    counterworld: str
    kill_tests: list[str]
    local_evidence_refs: list[str]
    source_refs: list[str]
    limitations: list[str]
    def to_dict(self):
        d=asdict(self);d['packet_hash']=sha256_obj(d);return d

@dataclass(frozen=True)
class MillenniumPacket:
    problem_id: str
    exact_proposition: str
    candidate_verdict: str
    official_status: str
    continuation_reduction: str
    decisive_lemma: str
    proof_program: list[str]
    known_barriers: list[str]
    falsification_tests: list[str]
    evidence_boundary: str
    source_refs: list[str]
    def to_dict(self):
        d=asdict(self);d['packet_hash']=sha256_obj(d);return d
