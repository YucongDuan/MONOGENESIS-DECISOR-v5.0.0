from __future__ import annotations
from .models import MillenniumPacket
from .canonical import sha256_obj

def millennium_packets()->list[MillenniumPacket]:
    common=('This is a proof-campaign object. Except for the Poincare theorem, it is not an externally established solution. '
            'The polarity is a falsifiable semantic candidate and must not be cited as a theorem until the decisive lemma is independently proved and checked.')
    return [
      MillenniumPacket('poincare','Every closed simply connected 3-manifold is homeomorphic to S^3.','TRUE','SOLVED',
        'Local curvature evolution and surgery continuations glue to one global topological classification.',
        'Ricci flow with surgery becomes extinct for closed simply connected 3-manifolds and reconstructs S^3.',
        ['Start Ricci flow from an arbitrary metric.','Classify singularity models.','Perform controlled surgery.','Use extinction and geometrization to identify the manifold.'],
        ['Singularity control and non-collapsing were the historical barriers.'],['Replay the accepted proof chain or exhibit a counterexample manifold.'],
        'Established theorem; included as the calibration case.',['Clay Poincare problem page','Perelman/Ricci-flow literature']),
      MillenniumPacket('p-vs-np','P = NP.','FALSE (candidate: P != NP)','OPEN',
        'A polynomial selector must preserve future witness extendability for all polynomially balanced NP verifiers with total resource cost included.',
        'For every uniform polynomial-time continuation selector there exists an explicit 3-SAT family with two selector-indistinguishable prefixes of opposite extendability.',
        ['Define continuation equivalence of witness prefixes.','Construct an algorithm-indexed adversarial formula family.','Force a same-state/opposite-extendability collision.','Diagonalize to refute the selector.'],
        ['Relativization','natural-proofs barrier','algebrization','hidden preprocessing/advice'],
        ['Produce a correct polynomial-time SAT algorithm.','Show the adversarial family cannot diagonalize against every uniform selector.','Show the invariant loses the exact structured-verifier object.'],common,['Clay P vs NP official description']),
      MillenniumPacket('riemann-hypothesis','Every nontrivial zero of zeta(s) has real part 1/2.','TRUE (candidate)','OPEN',
        'Prime-power continuations and zero locations are dual descriptions of one oscillatory residual.',
        'The Weil explicit-formula quadratic form factors as a norm square of a prime-continuation operator on the full admissible test space.',
        ['Fix the Weil criterion.','Construct the operator from prime-power weights.','Prove exact domain and boundary-term control.','Obtain positivity for every admissible test function.'],
        ['Controlling the complete test space','boundary terms','avoiding numerical-only positivity'],
        ['Find an off-line zero.','Find an admissible test function with negative Weil form.','Break the operator factorization.'],common,['Clay Riemann official description']),
      MillenniumPacket('bsd-conjecture','For every elliptic curve over Q, algebraic rank equals analytic rank.','TRUE (candidate)','OPEN',
        'Local arithmetic continuations glue through a Selmer complex; the residual dimension appears analytically as an L-function zero.',
        'The Selmer continuation complex has kernel dimension equal to Mordell-Weil rank and determinant order equal to ord_{s=1} L(E,s).',
        ['Build the derived Selmer complex.','Identify kernel and cokernel with arithmetic groups.','Relate its determinant line to the L-function leading term.','Compare dimensions and orders.'],
        ['Global duality','Tate-Shafarevich finiteness','integrality of determinant comparisons'],
        ['Exhibit a curve with unequal ranks.','Break the determinant-line comparison.'],common,['Clay BSD official description']),
      MillenniumPacket('hodge-conjecture','Every rational Hodge class on a smooth projective complex variety is a rational combination of algebraic cycle classes.','TRUE (candidate)','OPEN',
        'A rational (p,p) continuation that survives all admissible deformations should close as an algebraic-cycle continuation.',
        'Compatible cycle approximants to a rational Hodge class admit a uniform algebraic-complexity bound and therefore algebraize.',
        ['Represent the class harmonically.','Construct integral-current or cycle approximants.','Prove refinement compatibility.','Establish a uniform complexity bound.','Algebraize the limit.'],
        ['Uniform complexity','transcendental intermediate Jacobians','degenerating families'],
        ['Construct a nonalgebraic rational Hodge class.','Show compatible approximants require unbounded complexity.'],common,['Clay Hodge official description']),
      MillenniumPacket('navier-stokes-3d','Every smooth divergence-free finite-energy 3D datum yields a unique global smooth solution.','TRUE (candidate: global regularity)','OPEN',
        'A singularity requires a coherent cascade whose vorticity concentration outruns geometric depletion at every scale.',
        'A dimensionless concentration-alignment residual satisfies a coercive multiscale inequality that forbids a finite-time blow-up profile.',
        ['Define the residual on dyadic cylinders.','Derive its local energy and vorticity evolution.','Exploit pressure cancellation and alignment depletion.','Prove a scale-independent coercive bound.','Apply the continuation criterion.'],
        ['Supercritical estimates','pressure nonlocality','intermittent concentration'],
        ['Construct a smooth-data blow-up.','Find an admissible profile violating coercivity.'],common,['Clay Navier-Stokes official description']),
      MillenniumPacket('yang-mills-mass-gap','A nontrivial quantum Yang-Mills theory on R^4 exists and has a positive mass gap.','TRUE (candidate)','OPEN',
        'Gauge-compatible lattice continuations should converge while retaining a positive transfer-matrix separation.',
        'Reflection-positive lattice measures have a continuum-tight family and a spectral gap bounded below uniformly in lattice spacing.',
        ['Construct gauge-invariant lattice measures.','Prove reflection positivity and uniform correlation decay.','Obtain a spacing-independent gap.','Take a continuum limit satisfying the axioms.'],
        ['Nonperturbative continuum construction','uniform renormalization control','gap survival in the limit'],
        ['Show every continuum scaling makes the gap vanish.','Prove non-tightness or triviality of the measure family.'],common,['Clay Yang-Mills official description']),
    ]

def registry()->dict:
    ps=[p.to_dict() for p in millennium_packets()]
    obj={'schema':'MONOGENESIS_DECISOR_MILLENNIUM_REGISTRY_V1','as_of':'2026-07-28','count':len(ps),'packets':ps}
    obj['registry_hash']=sha256_obj(obj);return obj
