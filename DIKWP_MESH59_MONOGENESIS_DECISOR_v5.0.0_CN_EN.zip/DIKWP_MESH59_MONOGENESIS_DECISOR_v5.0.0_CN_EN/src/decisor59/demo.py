from __future__ import annotations
from pathlib import Path
from .experiments import run_experiments
from .polarity import compile_polarity_registry
from .millennium import registry as millennium_registry
from .metatheory import theorem_registry
from .ledger import EvidenceLedger
from .canonical import write_json,sha256_obj
from .dashboard import build_dashboard,build_studio

def run_demo(out:str|Path,run_experiments_flag:bool=True)->dict:
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    receipts=[r.to_dict() for r in run_experiments()] if run_experiments_flag else []
    polarity=compile_polarity_registry(receipts);millennium=millennium_registry();theorems=theorem_registry();ledger=EvidenceLedger()
    for r in receipts:ledger.append('experiment',r)
    for p in polarity['packets']:ledger.append('polarity_packet',p)
    for p in millennium['packets']:ledger.append('millennium_packet',p)
    for t in theorems['theorems']:ledger.append('metatheorem',t)
    bundle={'schema':'MONOGENESIS_DECISOR_REFERENCE_RUN_V1','version':'5.0.0','as_of':'2026-07-28','primitive':'CAN_CONTINUE_AS',
      'completion':'S5.9-FINITE-REGISTRY-POLARITY-ASSIGNED-PROOF-CERTIFICATES-MIXED',
      'evidence_grade':'E2_AUTHOR_SIDE_DETERMINISTIC_REFERENCE',
      'source_boundary':{
        'attached_report':'Semantic Genesis 5.9 supplies the non-monopoly, proof-type separation, finite-contact barrier, concept-genesis and open-reflection constraints.',
        'new_extension':'The least-residual comparator, all candidate features, candidate truth assignments and decisive lemmas are independent extensions, not conclusions found in the attachment.',
        'claim_boundary':'Except for established proof/counterexample packets, TRUE/FALSE is a reproducible semantic research verdict and not an accepted mathematical solution.'},
      'polarity':polarity,'millennium':millennium,'metatheory':theorems,'experiments':receipts,'ledger':ledger.to_dict()}
    bundle['run_hash']=sha256_obj(bundle)
    write_json(out/'reference_run.json',bundle);write_json(out/'polarity_registry.json',polarity);write_json(out/'millennium_resolution_packets.json',millennium)
    write_json(out/'metatheorem_registry.json',theorems);write_json(out/'experiment_receipts.json',{'receipts':receipts});write_json(out/'evidence_ledger.json',ledger.to_dict())
    build_dashboard(bundle,out/'dashboard.html');build_studio(bundle,out/'studio.html')
    return {'status':'PASS','out':str(out),'run_hash':bundle['run_hash'],'packet_count':polarity['packet_count'],'true_count':polarity['true_count'],
            'false_count':polarity['false_count'],'experiment_count':len(receipts),'ledger_head':ledger.verify()['head']}
