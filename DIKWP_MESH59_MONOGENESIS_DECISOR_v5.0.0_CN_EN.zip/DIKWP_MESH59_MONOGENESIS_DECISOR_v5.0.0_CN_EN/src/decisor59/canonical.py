from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path
from typing import Any


def canonical_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(canonical_bytes(obj)).hexdigest()


def _split_zip_member(path: str) -> tuple[str, str] | None:
    """Resolve a zipimport pseudo-path such as ``app.pyz/pkg/module.py``."""
    normalized = path.replace("\\", "/")
    for marker in (".pyz/", ".zip/"):
        pos = normalized.lower().find(marker)
        if pos >= 0:
            archive = normalized[: pos + len(marker) - 1]
            member = normalized[pos + len(marker) :]
            return archive, member
    return None


def sha256_file(path: str | Path) -> str:
    """Hash a real file or a source member loaded from a zipapp archive."""
    path_text = str(path)
    h = hashlib.sha256()
    try:
        with open(path_text, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    except (FileNotFoundError, NotADirectoryError):
        zipped = _split_zip_member(path_text)
        if zipped is None:
            raise
        archive, member = zipped
        with zipfile.ZipFile(archive, "r") as zf:
            h.update(zf.read(member))
        return h.hexdigest()


def write_json(path: str | Path, obj: Any) -> None:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(
        json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
