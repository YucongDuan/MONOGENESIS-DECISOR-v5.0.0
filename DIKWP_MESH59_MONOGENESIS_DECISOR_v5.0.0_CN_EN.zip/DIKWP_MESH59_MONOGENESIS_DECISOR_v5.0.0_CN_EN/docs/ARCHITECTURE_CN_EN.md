# 系统架构

1. `atlas.py`：36个传统命题的对象、量词、操作、资源和反例地址。
2. `polarity.py`：决定性证书优先的最小余量比较器与敏感度审计。
3. `millennium.py`：七个千禧年问题的证明战役包。
4. `experiments.py`：27项可重复有限、符号和数值接触实验。
5. `metatheory.py`：14项边界和构造元定理。
6. `ledger.py`：追加式哈希链证据账本。
7. `dashboard.py`：离线驾驶舱和权重敏感度工作台。
8. `artifacts.py`：Draft 2020-12 JSON Schema 验证。
9. `conformance.py`：不可变量、篡改检测和状态边界检查。
