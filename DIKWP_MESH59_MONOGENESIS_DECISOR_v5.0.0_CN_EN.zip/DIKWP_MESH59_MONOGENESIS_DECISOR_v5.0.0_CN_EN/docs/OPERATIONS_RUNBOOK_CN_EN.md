# 运行手册

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install dist/dikwp_mesh59_monogenesis_decisor-5.0.0-py3-none-any.whl

decisor59 conformance --out outputs/conformance.json
decisor59 demo --out outputs/my-run
decisor59 artifacts-validate --root outputs/my-run --out outputs/artifact-validation.json
```

查看：

- `outputs/my-run/dashboard.html`
- `outputs/my-run/studio.html`
- `outputs/my-run/millennium_resolution_packets.json`
- `outputs/my-run/polarity_registry.json`

研究者修改权重或特征时，必须发布完整差异、原因和重新生成的哈希；不得只发布有利极性。
